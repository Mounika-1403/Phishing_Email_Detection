@echo off
title PhishGuard AI - Phishing Email Detection System
color 0B
chcp 65001 >nul

echo ===============================================================================
echo                PHISHGUARD AI - REAL-TIME CYBERSECURITY SOC
echo             AI-Powered Phishing Email Detection & Threat Monitor
echo ===============================================================================
echo.

cd /d "%~dp0"
set PYTHONIOENCODING=utf-8

:: Locate Python
set PYTHON_EXE=
if exist "C:\Users\lokes\AppData\Local\Python\pythoncore-3.14-64\python.exe" (
    set "PYTHON_EXE=C:\Users\lokes\AppData\Local\Python\pythoncore-3.14-64\python.exe"
) else (
    where python >nul 2>nul
    if %errorlevel% equ 0 (
        set "PYTHON_EXE=python"
    ) else (
        where py >nul 2>nul
        if %errorlevel% equ 0 (
            set "PYTHON_EXE=py"
        )
    )
)

if "%PYTHON_EXE%"=="" (
    color 0C
    echo [ERROR] Python was not found on your system!
    echo Please install Python 3.8+ or configure your system PATH.
    pause
    exit /b 1
)

echo [INFO] Using Python: %PYTHON_EXE%
echo [INFO] Initializing Real-Time ML Engine (Random Forest + SVM)...
echo [INFO] Zero-Configuration Local Database: Active (SQLite / MySQL)
echo.

:: Launch browser in background after 2 seconds
start "" cmd /c "timeout /t 2 /nobreak >nul & start http://localhost:5000"

:: Start the Flask Web Application
"%PYTHON_EXE%" -X utf8 app.py

pause

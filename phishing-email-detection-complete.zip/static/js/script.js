// PhishGuard AI - Real-Time Cybersecurity SOC Client Script

document.addEventListener('DOMContentLoaded', function() {
    // Elements
    const emailForm = document.getElementById('emailAnalysisForm');
    const emailText = document.getElementById('emailText');
    const analyzeBtn = document.getElementById('analyzeBtn');
    const clearTextBtn = document.getElementById('clearTextBtn');
    const charCount = document.getElementById('charCount');
    const wordCount = document.getElementById('wordCount');

    // Result Containers
    const resultsIdle = document.getElementById('resultsIdle');
    const loadingSection = document.getElementById('loadingSection');
    const resultsSection = document.getElementById('resultsSection');

    // Result Elements
    const verdictTitle = document.getElementById('verdictTitle');
    const verdictBadgeContainer = document.getElementById('verdictBadgeContainer');
    const gaugeScore = document.getElementById('gaugeScore');
    const gaugeNeedle = document.getElementById('gaugeNeedle');
    const riskLevelDescriptor = document.getElementById('riskLevelDescriptor');
    const ensembleVoteText = document.getElementById('ensembleVoteText');
    const rfConfidenceText = document.getElementById('rfConfidenceText');
    const rfProgressBar = document.getElementById('rfProgressBar');
    const svmConfidenceText = document.getElementById('svmConfidenceText');
    const svmProgressBar = document.getElementById('svmProgressBar');
    const threatIndicatorsContainer = document.getElementById('threatIndicatorsContainer');
    const highlightedEmailContent = document.getElementById('highlightedEmailContent');
    const confirmCorrectBtn = document.getElementById('confirmCorrectBtn');
    const reportErrorBtn = document.getElementById('reportErrorBtn');

    let currentEmailHash = '';
    let currentPrediction = 0;

    // Stream Elements
    const toggleStreamBtn = document.getElementById('toggleStreamBtn');
    const clearStreamBtn = document.getElementById('clearStreamBtn');
    const socStreamTableBody = document.getElementById('socStreamTableBody');
    const socTotalCount = document.getElementById('socTotalCount');
    const socPhishCount = document.getElementById('socPhishCount');
    const socCleanCount = document.getElementById('socCleanCount');
    const socAvgRisk = document.getElementById('socAvgRisk');

    let isStreaming = false;
    let streamTimer = null;
    let streamStats = { total: 0, phish: 0, clean: 0, riskSum: 0 };

    // IMAP Elements
    const imapScanForm = document.getElementById('imapScanForm');
    const runImapBtn = document.getElementById('runImapBtn');
    const imapResultsArea = document.getElementById('imapResultsArea');
    const imapMessagesList = document.getElementById('imapMessagesList');

    // Samples Cache
    let cachedSamples = {};

    // -------------------------------------------------------------
    // 1. Load Sample Emails from Backend
    // -------------------------------------------------------------
    fetch('/api/samples')
        .then(res => res.json())
        .then(data => {
            if (data.samples) {
                data.samples.forEach(s => {
                    cachedSamples[s.id] = s;
                });
            }
        })
        .catch(err => console.warn('Could not pre-fetch samples:', err));

    // Handle Quick Sample Pill Clicks
    document.querySelectorAll('.sample-pill').forEach(btn => {
        btn.addEventListener('click', function() {
            const sampleId = this.getAttribute('data-sample');
            if (cachedSamples[sampleId]) {
                emailText.value = cachedSamples[sampleId].body;
                updateCounts();
                // Trigger auto-analysis
                analyzeEmail();
            }
        });
    });

    // -------------------------------------------------------------
    // 2. Character & Word Counter
    // -------------------------------------------------------------
    function updateCounts() {
        if (!emailText) return;
        const text = emailText.value;
        if (charCount) charCount.textContent = text.length;
        if (wordCount) {
            const words = text.trim() ? text.trim().split(/\s+/).length : 0;
            wordCount.textContent = words;
        }
    }

    if (emailText) {
        emailText.addEventListener('input', updateCounts);
    }

    if (clearTextBtn) {
        clearTextBtn.addEventListener('click', function() {
            if (emailText) {
                emailText.value = '';
                updateCounts();
            }
            showState('idle');
        });
    }

    // -------------------------------------------------------------
    // 3. Email Analysis Handler
    // -------------------------------------------------------------
    if (emailForm) {
        emailForm.addEventListener('submit', function(e) {
            e.preventDefault();
            analyzeEmail();
        });
    }

    function showState(state) {
        if (resultsIdle) resultsIdle.classList.toggle('d-none', state !== 'idle');
        if (loadingSection) {
            loadingSection.classList.toggle('d-none', state !== 'loading');
            loadingSection.classList.toggle('d-flex', state === 'loading');
        }
        if (resultsSection) resultsSection.classList.toggle('d-none', state !== 'results');

        if (analyzeBtn) {
            analyzeBtn.disabled = (state === 'loading');
            analyzeBtn.innerHTML = (state === 'loading') 
                ? '<i class="fas fa-spinner fa-spin me-2"></i>Analyzing Markers...' 
                : '<i class="fas fa-shield-virus me-2"></i>Run AI Phishing Analysis';
        }
    }

    function analyzeEmail() {
        const text = emailText.value.trim();
        if (!text) {
            alert('Please enter or select email content to analyze.');
            return;
        }

        showState('loading');

        fetch('/analyze', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email_text: text })
        })
        .then(res => {
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            return res.json();
        })
        .then(data => {
            renderAnalysisResults(data, text);
            showState('results');
        })
        .catch(err => {
            console.error('Analysis error:', err);
            showState('idle');
            alert('Analysis failed: ' + err.message);
        });
    }

    // -------------------------------------------------------------
    // 4. Render Analysis Results & Speedometer Needle
    // -------------------------------------------------------------
    function renderAnalysisResults(data, rawText) {
        const ensemble = data.ensemble_prediction || {};
        const individual = data.individual_predictions || {};
        const analysis = data.email_analysis || {};
        const isPhish = ensemble.prediction === 1;

        currentEmailHash = data.email_hash || '';
        currentPrediction = ensemble.prediction;

        // Verdict & Badges
        if (verdictTitle) {
            verdictTitle.textContent = isPhish ? 'Phishing Threat Detected' : 'Verified Legitimate Email';
            verdictTitle.className = isPhish ? 'mb-0 fw-bold mt-1 text-danger' : 'mb-0 fw-bold mt-1 text-success';
        }

        if (verdictBadgeContainer) {
            verdictBadgeContainer.innerHTML = isPhish
                ? '<span class="badge bg-danger fs-6 px-3 py-2"><i class="fas fa-biohazard me-1"></i> MALICIOUS</span>'
                : '<span class="badge bg-success fs-6 px-3 py-2"><i class="fas fa-shield-check me-1"></i> SAFE</span>';
        }

        // Risk Score & Needle Rotation (-90deg to +90deg)
        const riskScore = Math.min(Math.max(analysis.risk_score || (isPhish ? 75 : 10), 0), 100);
        if (gaugeScore) gaugeScore.textContent = Math.round(riskScore);

        const needleAngle = -90 + (riskScore / 100) * 180;
        if (gaugeNeedle) {
            gaugeNeedle.style.transform = `rotate(${needleAngle}deg)`;
        }

        if (riskLevelDescriptor) {
            if (riskScore >= 70) {
                riskLevelDescriptor.innerHTML = '<span class="text-danger fw-bold"><i class="fas fa-circle-exclamation me-1"></i>CRITICAL RISK:</span> High probability of credential harvesting or scam.';
            } else if (riskScore >= 35) {
                riskLevelDescriptor.innerHTML = '<span class="text-warning fw-bold"><i class="fas fa-triangle-exclamation me-1"></i>SUSPICIOUS:</span> Anomalous elements detected, exercise caution.';
            } else {
                riskLevelDescriptor.innerHTML = '<span class="text-success fw-bold"><i class="fas fa-circle-check me-1"></i>LOW RISK:</span> Normal communication structure and verified markers.';
            }
        }

        // Model Consensus & Bars
        if (ensembleVoteText) {
            ensembleVoteText.textContent = ensemble.votes || (ensemble.agreement ? 'Unanimous Agreement' : 'Mixed Model Verdict');
        }

        // Random Forest
        if (individual.random_forest) {
            const rfConf = (individual.random_forest.confidence * 100).toFixed(1);
            if (rfConfidenceText) rfConfidenceText.textContent = `${rfConf}% (${individual.random_forest.label})`;
            if (rfProgressBar) {
                rfProgressBar.style.width = `${rfConf}%`;
                rfProgressBar.className = individual.random_forest.prediction === 1 ? 'progress-bar bg-danger' : 'progress-bar bg-success';
            }
        }

        // SVM
        if (individual.svm) {
            const svmConf = (individual.svm.confidence * 100).toFixed(1);
            if (svmConfidenceText) svmConfidenceText.textContent = `${svmConf}% (${individual.svm.label})`;
            if (svmProgressBar) {
                svmProgressBar.style.width = `${svmConf}%`;
                svmProgressBar.className = individual.svm.prediction === 1 ? 'progress-bar bg-danger' : 'progress-bar bg-success';
            }
        }

        // Threat Chips
        if (threatIndicatorsContainer) {
            const indicators = analysis.suspicious_indicators || [];
            if (indicators.length > 0) {
                threatIndicatorsContainer.innerHTML = indicators.map(ind => 
                    `<div class="threat-indicator-chip"><i class="fas fa-exclamation-circle"></i><span>${ind}</span></div>`
                ).join('');
            } else {
                threatIndicatorsContainer.innerHTML = `
                    <div class="safe-indicator-chip">
                        <i class="fas fa-check-double"></i>
                        <span>No deceptive keywords, URL masks, or coercive patterns found.</span>
                    </div>
                `;
            }
        }

        // Highlight Keywords in Text
        renderHighlightedText(rawText);
    }

    function renderHighlightedText(text) {
        if (!highlightedEmailContent) return;

        // Keywords from config to highlight
        const suspiciousWords = [
            'urgent', 'verify', 'suspended', 'click here', 'limited time',
            'act now', 'congratulations', 'winner', 'lottery', 'prize',
            'free money', 'guaranteed', 'risk free', 'update payment',
            'confirm identity', 'account suspended', 'security alert', 'compromised'
        ];

        let safeEscaped = text
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');

        // Highlight URLs
        safeEscaped = safeEscaped.replace(/(https?:\/\/[^\s]+)/gi, '<span class="highlight-url">$1</span>');

        // Highlight keywords
        suspiciousWords.forEach(word => {
            const regex = new RegExp(`\\b(${word})\\b`, 'gi');
            safeEscaped = safeEscaped.replace(regex, '<span class="highlight-danger">$1</span>');
        });

        highlightedEmailContent.innerHTML = safeEscaped;
    }

    // -------------------------------------------------------------
    // 5. User Feedback Buttons
    // -------------------------------------------------------------
    if (confirmCorrectBtn) {
        confirmCorrectBtn.addEventListener('click', function() {
            sendFeedback(currentPrediction);
        });
    }

    if (reportErrorBtn) {
        reportErrorBtn.addEventListener('click', function() {
            const inverted = currentPrediction === 1 ? 0 : 1;
            sendFeedback(inverted);
        });
    }

    function sendFeedback(label) {
        if (!currentEmailHash) return;
        fetch('/feedback', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email_hash: currentEmailHash, actual_label: label })
        })
        .then(res => res.json())
        .then(data => {
            alert('Thank you! Feedback recorded into real-time accuracy tracker.');
        })
        .catch(err => console.error('Feedback error:', err));
    }

    // -------------------------------------------------------------
    // 6. Real-Time SOC Stream Simulator
    // -------------------------------------------------------------
    if (toggleStreamBtn) {
        toggleStreamBtn.addEventListener('click', function() {
            isStreaming = !isStreaming;
            if (isStreaming) {
                toggleStreamBtn.innerHTML = '<i class="fas fa-pause me-1"></i> Pause Stream';
                toggleStreamBtn.className = 'btn btn-sm btn-outline-danger';
                fetchStreamEvent(); // immediate first fetch
                streamTimer = setInterval(fetchStreamEvent, 3500);
            } else {
                toggleStreamBtn.innerHTML = '<i class="fas fa-play me-1"></i> Start Stream';
                toggleStreamBtn.className = 'btn btn-sm btn-cyber-primary';
                clearInterval(streamTimer);
            }
        });
    }

    if (clearStreamBtn) {
        clearStreamBtn.addEventListener('click', function() {
            if (socStreamTableBody) {
                socStreamTableBody.innerHTML = '<tr><td colspan="7" class="text-center text-secondary py-4">Stream log cleared.</td></tr>';
            }
            streamStats = { total: 0, phish: 0, clean: 0, riskSum: 0 };
            updateSocKpis();
        });
    }

    function fetchStreamEvent() {
        fetch('/api/stream/random')
            .then(res => res.json())
            .then(data => {
                if (data.error) return;
                appendStreamRow(data);
            })
            .catch(err => console.warn('Stream poll error:', err));
    }

    function appendStreamRow(data) {
        if (!socStreamTableBody) return;

        // If placeholder row exists, clear it
        if (streamStats.total === 0) {
            socStreamTableBody.innerHTML = '';
        }

        const isPhish = data.prediction.prediction === 1;
        const riskScore = data.email_analysis.risk_score || (isPhish ? 75 : 12);

        // Update stats
        streamStats.total++;
        if (isPhish) streamStats.phish++;
        else streamStats.clean++;
        streamStats.riskSum += riskScore;
        updateSocKpis();

        const tr = document.createElement('tr');
        tr.className = 'new-row';
        tr.innerHTML = `
            <td class="text-secondary small">${data.timestamp || 'Just now'}</td>
            <td><code class="text-light">${data.sender || 'Unknown'}</code></td>
            <td class="text-truncate" style="max-width: 260px;" title="${data.subject}">${data.subject}</td>
            <td>
                ${isPhish 
                    ? '<span class="badge-phish"><i class="fas fa-triangle-exclamation me-1"></i>Phishing</span>'
                    : '<span class="badge-legit"><i class="fas fa-check-circle me-1"></i>Safe</span>'
                }
            </td>
            <td>${(data.prediction.confidence * 100).toFixed(1)}%</td>
            <td>
                <span class="badge ${riskScore >= 50 ? 'bg-danger-subtle text-danger' : 'bg-success-subtle text-success'}">
                    ${Math.round(riskScore)}%
                </span>
            </td>
            <td>
                ${isPhish 
                    ? '<span class="text-danger small fw-semibold"><i class="fas fa-ban me-1"></i>Quarantined</span>' 
                    : '<span class="text-success small fw-semibold"><i class="fas fa-envelope-circle-check me-1"></i>Delivered</span>'
                }
            </td>
        `;

        socStreamTableBody.insertBefore(tr, socStreamTableBody.firstChild);

        // Keep maximum 25 rows
        if (socStreamTableBody.children.length > 25) {
            socStreamTableBody.removeChild(socStreamTableBody.lastChild);
        }
    }

    function updateSocKpis() {
        if (socTotalCount) socTotalCount.textContent = streamStats.total;
        if (socPhishCount) socPhishCount.textContent = streamStats.phish;
        if (socCleanCount) socCleanCount.textContent = streamStats.clean;
        if (socAvgRisk) {
            const avg = streamStats.total > 0 ? Math.round(streamStats.riskSum / streamStats.total) : 0;
            socAvgRisk.textContent = `${avg}%`;
        }
    }

    // -------------------------------------------------------------
    // 7. Live IMAP Mailbox Scanner
    // -------------------------------------------------------------
    if (imapScanForm) {
        imapScanForm.addEventListener('submit', function(e) {
            e.preventDefault();
            runImapScan();
        });
    }

    function runImapScan() {
        const host = document.getElementById('imapHost').value.trim();
        const port = parseInt(document.getElementById('imapPort').value) || 993;
        const email = document.getElementById('imapEmail').value.trim();
        const password = document.getElementById('imapPass').value.trim();

        if (runImapBtn) {
            runImapBtn.disabled = true;
            runImapBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> Connecting & Scanning...';
        }

        fetch('/api/imap/scan', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                server: host,
                port: port,
                email: email,
                password: password,
                limit: 5
            })
        })
        .then(res => res.json())
        .then(data => {
            if (data.error) {
                alert('IMAP Scan Error: ' + data.error);
                return;
            }
            renderImapResults(data);
        })
        .catch(err => {
            console.error('IMAP fetch error:', err);
            alert('Failed to connect to IMAP server: ' + err.message);
        })
        .finally(() => {
            if (runImapBtn) {
                runImapBtn.disabled = false;
                runImapBtn.innerHTML = '<i class="fas fa-radar me-1"></i> Scan Mailbox Now';
            }
        });
    }

    function renderImapResults(data) {
        if (!imapResultsArea || !imapMessagesList) return;

        imapResultsArea.classList.remove('d-none');
        imapMessagesList.innerHTML = '';

        if (!data.results || data.results.length === 0) {
            imapMessagesList.innerHTML = '<div class="alert alert-secondary">No unread emails found in inbox.</div>';
            return;
        }

        data.results.forEach((msg, idx) => {
            const isPhish = msg.prediction === 'Phishing';
            const card = document.createElement('div');
            card.className = `cyber-card p-3 mb-2 border-${isPhish ? 'danger' : 'success'}`;
            card.innerHTML = `
                <div class="d-flex justify-content-between align-items-center mb-1">
                    <strong class="text-light">${msg.subject}</strong>
                    <span class="badge ${isPhish ? 'bg-danger' : 'bg-success'}">${msg.prediction}</span>
                </div>
                <div class="small text-secondary mb-2">From: <code>${msg.from}</code> | Confidence: ${(msg.confidence * 100).toFixed(1)}% | Risk: ${msg.risk_score}%</div>
                <div class="small text-muted bg-dark p-2 rounded text-truncate">${msg.raw_preview}</div>
            `;
            imapMessagesList.appendChild(card);
        });
    }

});

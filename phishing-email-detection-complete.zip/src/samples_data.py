"""
Sample dataset and streaming emails for real-time demonstration.
Contains realistic phishing attack vectors and legitimate business communications.
"""

SAMPLE_EMAILS = [
    {
        "id": "phish_chase",
        "category": "phishing",
        "title": "Chase Bank Account Alert",
        "sender": "security-alert@chse-bank.com",
        "subject": "URGENT: Suspicious Activity Detected on Your Account",
        "body": """From: security-alert@chse-bank.com
To: victim@email.com
Subject: URGENT: Suspicious Activity Detected on Your Account

SECURITY ALERT - IMMEDIATE ACTION REQUIRED

Dear Customer,

We have detected suspicious activity on your Chase bank account ending in **67. For your security, we have temporarily limited access to your account.

Suspicious Activity Detected:
- Login attempt from unknown device
- Location: Lagos, Nigeria
- Time: Today at 3:47 AM

To restore full access to your account, please verify your identity immediately by clicking the link below:

http://chase-security-verify.net/login

WARNING: If you do not verify your account within 24 hours, your account will be permanently suspended and funds frozen.

Chase Security Team
Chase Bank N.A."""
    },
    {
        "id": "phish_paypal",
        "category": "phishing",
        "title": "PayPal Suspension Notice",
        "sender": "service@paypa1-account-update.com",
        "subject": "Your PayPal Account Access Has Been Restricted",
        "body": """From: service@paypa1-account-update.com
To: user@example.com
Subject: Your PayPal Account Access Has Been Restricted

Dear Valued Customer,

We have noticed unusual charges on your PayPal account. As a security precaution, we have limited what you can do with your account until you verify your information.

Please visit the link below to verify your identity and update payment information:
http://bit.ly/paypal-account-restore

If you do not update your details within 12 hours, your account will be closed.

Sincerely,
PayPal Security Center"""
    },
    {
        "id": "phish_lottery",
        "category": "phishing",
        "title": "International Lottery Winner",
        "sender": "claims@mega-millions-prize.org",
        "subject": "CONGRATULATIONS: You have won $2,500,000.00 USD!",
        "body": """From: claims@mega-millions-prize.org
To: lucky.winner@domain.com
Subject: CONGRATULATIONS: You have won $2,500,000.00 USD!

OFFICIAL NOTIFICATION

Dear Lucky Beneficiary,

We are pleased to inform you that your email address was selected as the winner of $2,500,000.00 in the International Email Lottery Program!

To claim your prize, please send your full name, bank details, and copy of passport immediately to our fiduciary agent. Click here to confirm identity: http://claim-prize-intl.tk/verify

Act now, limited time before funds are returned to government escrow!"""
    },
    {
        "id": "phish_microsoft",
        "category": "phishing",
        "title": "Microsoft Virus Warning",
        "sender": "helpdesk@micr0soft-security-fix.net",
        "subject": "CRITICAL ALERT: Your Windows System is Compromised",
        "body": """From: helpdesk@micr0soft-security-fix.net
To: windows-user@office.com
Subject: CRITICAL ALERT: Your Windows System is Compromised

VIRUS ALERT - IMMEDIATE ATTENTION REQUIRED

Dear Windows User,
Our cloud security scanner has detected multiple Trojan infections on your workstation. 

Passwords, crypto wallets, and corporate documents may have been compromised. Click below to download our emergency patch immediately:
http://windows-defender-hotfix.online/cleaner.exe

Microsoft Windows Security Desk"""
    },
    {
        "id": "legit_amazon",
        "category": "legitimate",
        "title": "Amazon Order Confirmation",
        "sender": "orders@amazon.com",
        "subject": "Your Amazon.com order #112-9847291-8837190",
        "body": """From: orders@amazon.com
To: shopper@example.com
Subject: Your Amazon.com order #112-9847291-8837190

Hello Customer,

Thank you for your order. We will let you know when items ship.

Order Summary:
- Logitech MX Master 3S Wireless Mouse - $99.99
- Anker USB-C Hub Adapter - $29.99

Total Before Tax: $129.98
Estimated Tax: $10.40
Order Total: $140.38

Shipping to: 123 Tech Park Way
Estimated Delivery: Friday, Nov 3

You can view your order status anytime by visiting Amazon.com."""
    },
    {
        "id": "legit_github",
        "category": "legitimate",
        "title": "GitHub Weekly Digest",
        "sender": "notifications@github.com",
        "subject": "[GitHub] Weekly digest for your repositories",
        "body": """From: notifications@github.com
To: engineer@company.com
Subject: [GitHub] Weekly digest for your repositories

Hi Engineer,

Here is your weekly summary of activity across your starred and watched repositories:

Highlights:
- 12 pull requests merged across 4 repositories
- 5 new security advisories resolved
- Release v2.4.0 published for ml-inference-engine

You are receiving this because you subscribed to weekly summaries. Manage notifications in your GitHub profile settings.

The GitHub Team"""
    },
    {
        "id": "legit_meeting",
        "category": "legitimate",
        "title": "Team Sprint Review & Planning",
        "sender": "sarah.miller@enterprise.com",
        "subject": "Agenda: Q4 Sprint Planning Meeting - Thursday 2 PM",
        "body": """From: sarah.miller@enterprise.com
To: engineering-team@enterprise.com
Subject: Agenda: Q4 Sprint Planning Meeting - Thursday 2 PM

Hi Team,

Hope you are having a productive week.

Here is the agenda for our upcoming Sprint Planning meeting on Thursday at 2:00 PM in Conference Room B (and Google Meet):

1. Review Q3 OKR completions and metrics (15 mins)
2. Retrospective on sprint 24 blockers (15 mins)
3. Story point estimation for sprint 25 backlog (30 mins)

Please make sure all current Jira tickets are updated before the call.

Best regards,
Sarah Miller
Product Operations Lead"""
    }
]
